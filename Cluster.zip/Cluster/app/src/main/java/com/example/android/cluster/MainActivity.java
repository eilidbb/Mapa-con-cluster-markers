package com.example.android.cluster;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.example.android.cluster.model.Person;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import com.opencsv.CSVReader;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    GoogleMap m_map;
    boolean mapReady = false;
    int temp = 0;
    double lat;
    double longi;
    String titulo;
    String mSnippet;
    BitmapDescriptor mIcon;

    private ArrayList<Double> markersLats = new ArrayList<>();
    private ArrayList<Double> markersLngs = new ArrayList<>();
    private ArrayList<String> markersTitles = new ArrayList<>();
    //para cluster de elementos sin tomar en cuenta iconos
    //private ClusterManager<MyItem> mClusterManager;
    //para cluster con persnas e iconos
    private ClusterManager<Person> mClusterManager;






    private class PersonRenderer extends DefaultClusterRenderer<Person> {
        public PersonRenderer() {
            super(getApplicationContext(), m_map, mClusterManager);
        }
        @Override
        protected void onBeforeClusterItemRendered(Person person, MarkerOptions markerOptions) {
            BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(R.drawable.bob);
            markerOptions.icon(icon).title(person.name);
        }
    }









    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prepArray();
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    @Override
    public void onMapReady (GoogleMap map){
        mapReady = true;
        m_map = map;
        // creaMarcadores pone los marcadores directamente en el mapa
        //   creaMarcadores();
        setUpClusterer(m_map);
    }
    //inicializa el cluster
    private void setUpClusterer(GoogleMap map) {
        m_map = map;
        m_map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(19.693996500728243,-99.16878865600586), 10));
        // Initialize the manager with the context and the map.
        // (Activity extends context, so we can pass 'this' in the constructor.)
        mClusterManager = new ClusterManager<Person>(this, m_map);
        mClusterManager.setRenderer(new PersonRenderer()); ///////MAGIA!!!!!!!!!!!!!!!

        // Point the map's listeners at the listeners implemented by the cluster
        // manager.
        m_map.setOnCameraIdleListener(mClusterManager);
        m_map.setOnMarkerClickListener(mClusterManager);

        // Add cluster items (markers) to the cluster manager.
        creaMarcadoresEnCluster();
        mClusterManager.cluster();
    }
    /**MI CONSTRUCTOR DE CLUSTER ORIGINAL
    //lee los arreglos con los datos de las parroquias y los agrega al cluster
    private void creaMarcadoresEnCluster() {
        for(int i = 0 ; i < markersTitles.size() ; i++ ) {
            lat = markersLats.get(i);
            longi = markersLngs.get(i);
            titulo = markersTitles.get(i);
            mSnippet = null;
            MyItem elemento = new MyItem(lat ,longi, titulo, mSnippet);
            mClusterManager.addItem(elemento);

        }
    }**/
    //lee los arreglos con los datos de las parroquias y los agrega al cluster
    private void creaMarcadoresEnCluster() {
        for (int i = 0; i < markersTitles.size(); i++) {
            lat = markersLats.get(i);
            longi = markersLngs.get(i);
            titulo = markersTitles.get(i);
            mSnippet = null;
            Person elemento = new Person(new LatLng(lat ,longi), titulo, R.drawable.bob);
            mClusterManager.addItem(elemento);
        }
    }


    //lee los arreglos con los datos de las parroquias y crea los marcadores
    private void creaMarcadores() {
        for(int i = 0 ; i < markersTitles.size() ; i++ ) {
            lat = markersLats.get(i);
            longi = markersLngs.get(i);
            titulo = markersTitles.get(i);
            MarkerOptions marcador = new MarkerOptions()
                    .position(new LatLng(lat,longi))
                    .title(titulo);
            m_map.addMarker(marcador);
        }
    }
    //Mueve la cámara a la posición que se indica
    private void flyTo(CameraPosition target)
    {
        m_map.animateCamera(CameraUpdateFactory.newCameraPosition(target),5000,null);
    }
    //Lee el archivo libro.csv que está es assets y pone en arreglos cada columna
    private void prepArray() {
        try{
            InputStreamReader is = new InputStreamReader(getAssets()
                    .open("libro.csv"));
            BufferedReader reader = new BufferedReader(is);
            CSVReader readerer = new CSVReader(reader);//Specify asset file name
            String [] nextLine;
            while ((nextLine = readerer.readNext()) != null) {
                markersLats.add(Double.valueOf(nextLine[1]));
                markersLngs.add(Double.valueOf(nextLine[2]));
                markersTitles.add(nextLine[0]);
            }
        }catch(Exception e){
            e.printStackTrace();
            Toast.makeText(this, "The specified file was not found", Toast.LENGTH_SHORT).show();
        }
    }



























}
